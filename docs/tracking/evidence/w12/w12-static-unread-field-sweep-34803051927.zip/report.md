# Static unread serialized/snapshot field sweep

Diagnostic candidates only. A field is listed when production code writes it and the
lexical sweep finds no behavioral read. Serialization/capture/restore/codec reads are
reported as transport-only and intentionally do not clear the finding.

**Candidates:** 105

| Category | Field | Declaration | Writes | Transport-only reads |
|---|---|---|---:|---:|
| transport-only | `AgentState.LeanAngle` | `src/agent-movement/AgentState.cs:57` | 3 | 1 |
| transport-only | `AgentState.CurrentTurnRate` | `src/agent-movement/AgentState.cs:60` | 3 | 1 |
| transport-only | `OscillationGuardState.WriteIndex` | `src/agent-movement/OscillationGuardState.cs:36` | 1 | 2 |
| transport-only | `OscillationGuardState.IsLocked` | `src/agent-movement/OscillationGuardState.cs:39` | 1 | 2 |
| transport-only | `OscillationGuardState.LockUntilTime` | `src/agent-movement/OscillationGuardState.cs:42` | 1 | 2 |
| transport-only | `AttackingTickState.Hysteresis` | `src/attacking-ai/AttackingTickState.cs:27` | 1 | 3 |
| transport-only | `AttackingTickState.Transition` | `src/attacking-ai/AttackingTickState.cs:30` | 1 | 3 |
| transport-only | `AttackingTickState.LastInPossDirective` | `src/attacking-ai/AttackingTickState.cs:33` | 1 | 5 |
| transport-only | `CollisionContactState.Word0` | `src/collision-system/CollisionContactState.cs:21` | 1 | 2 |
| transport-only | `CollisionContactState.Word1` | `src/collision-system/CollisionContactState.cs:24` | 1 | 2 |
| transport-only | `CollisionContactState.Word2` | `src/collision-system/CollisionContactState.cs:27` | 1 | 2 |
| transport-only | `CollisionContactState.Word3` | `src/collision-system/CollisionContactState.cs:30` | 1 | 2 |
| transport-only | `DecisionTreeState.State` | `src/decision-tree/DecisionTreeState.cs:43` | 1 | 2 |
| snapshot/state-carrier | `DefensiveAgentSnapshot.HasBall` | `src/defensive-ai/DefensiveAgentSnapshot.cs:53` | 1 | 0 |
| snapshot/state-carrier | `DefensiveSnapshot.PossessionOwnerEntityId` | `src/defensive-ai/DefensiveSnapshot.cs:42` | 1 | 0 |
| transport-only | `DefensiveTickState.Hysteresis` | `src/defensive-ai/DefensiveTickState.cs:28` | 1 | 3 |
| transport-only | `DefensiveTickState.PrevAssignments` | `src/defensive-ai/DefensiveTickState.cs:31` | 1 | 2 |
| snapshot/state-carrier | `RngStreamState.DrawIndex` | `src/deterministic-sim/RngStreamState.cs:40` | 2 | 0 |
| snapshot/state-carrier | `RngStreamState.SiteId` | `src/deterministic-sim/RngStreamState.cs:43` | 1 | 0 |
| snapshot/state-carrier | `RngStreamState.StreamVersion` | `src/deterministic-sim/RngStreamState.cs:46` | 1 | 0 |
| snapshot/state-carrier | `RngStreamState.EntityId` | `src/deterministic-sim/RngStreamState.cs:52` | 1 | 0 |
| transport-only | `GkContactState.PredictedContactFrame` | `src/goalkeeper-mechanics/GkContactState.cs:23` | 2 | 1 |
| transport-only | `GkContactState.ActualContactFrame` | `src/goalkeeper-mechanics/GkContactState.cs:26` | 4 | 1 |
| transport-only | `GkContactState.HandlingQualityScalar` | `src/goalkeeper-mechanics/GkContactState.cs:35` | 7 | 1 |
| transport-only | `GoalkeeperTickState.Attrs` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:33` | 1 | 2 |
| transport-only | `GoalkeeperTickState.ContactStates` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:36` | 1 | 2 |
| transport-only | `GoalkeeperTickState.SaveIntents` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:39` | 1 | 2 |
| transport-only | `GoalkeeperTickState.SaveIntentActive` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:42` | 1 | 2 |
| transport-only | `GoalkeeperTickState.RushIntents` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:45` | 1 | 2 |
| transport-only | `GoalkeeperTickState.RushIntentActive` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:48` | 1 | 2 |
| transport-only | `GoalkeeperTickState.DistributeIntents` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:51` | 1 | 2 |
| transport-only | `GoalkeeperTickState.DistributeIntentActive` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:54` | 1 | 2 |
| transport-only | `GoalkeeperTickState.PositioningContracts` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:57` | 1 | 2 |
| transport-only | `GoalkeeperTickState.DiveLaunchFrames` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:60` | 1 | 2 |
| transport-only | `GoalkeeperTickState.DiveDurationFrames` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:63` | 1 | 2 |
| transport-only | `GoalkeeperTickState.DivePeakHandZ` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:66` | 1 | 2 |
| transport-only | `GoalkeeperTickState.DiveDirectionLateral` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:69` | 1 | 2 |
| transport-only | `GoalkeeperTickState.RushLaunchMps` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:72` | 3 | 2 |
| transport-only | `GoalkeeperTickState.RushInitialAttackerId` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:75` | 1 | 2 |
| transport-only | `GoalkeeperTickState.ShotDetectedTickMs` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:78` | 1 | 2 |
| transport-only | `GoalkeeperTickState.RequiredReactionMs` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:81` | 1 | 2 |
| transport-only | `GoalkeeperTickState.ShotEventPending` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:84` | 1 | 2 |
| transport-only | `GoalkeeperTickState.ClaimTick` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:87` | 1 | 2 |
| transport-only | `GoalkeeperTickState.ReleaseTickEarliest` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:90` | 1 | 2 |
| transport-only | `GoalkeeperTickState.RecoveryCooldownEndTick` | `src/goalkeeper-mechanics/GoalkeeperTickState.cs:93` | 1 | 2 |
| transport-only | `HeaderContactState.ContactPointError` | `src/heading-mechanics/HeaderContactState.cs:43` | 3 | 2 |
| transport-only | `HeaderContactState.DisturbanceFactor` | `src/heading-mechanics/HeaderContactState.cs:49` | 2 | 1 |
| transport-only | `HeadingTickState.ContactStates` | `src/heading-mechanics/HeadingTickState.cs:33` | 1 | 2 |
| transport-only | `HeadingTickState.IntentActive` | `src/heading-mechanics/HeadingTickState.cs:36` | 1 | 2 |
| transport-only | `HeadingTickState.BallSnapshotFrames` | `src/heading-mechanics/HeadingTickState.cs:39` | 1 | 2 |
| transport-only | `HeadingTickState.AgentAttrs` | `src/heading-mechanics/HeadingTickState.cs:42` | 1 | 2 |
| transport-only | `PassExecutorState.State` | `src/pass-mechanics/PassExecutorState.cs:37` | 1 | 2 |
| transport-only | `PassExecutorState.Request` | `src/pass-mechanics/PassExecutorState.cs:40` | 1 | 14 |
| transport-only | `PassExecutorState.EffectiveSubType` | `src/pass-mechanics/PassExecutorState.cs:43` | 1 | 3 |
| transport-only | `PassExecutorState.KickSpeed` | `src/pass-mechanics/PassExecutorState.cs:46` | 2 | 2 |
| transport-only | `PassExecutorState.LaunchAngleDeg` | `src/pass-mechanics/PassExecutorState.cs:49` | 2 | 2 |
| transport-only | `PassExecutorState.SpinVector` | `src/pass-mechanics/PassExecutorState.cs:52` | 1 | 4 |
| transport-only | `PassExecutorState.BaseKickDirection` | `src/pass-mechanics/PassExecutorState.cs:55` | 1 | 4 |
| transport-only | `PassExecutorState.AimPoint` | `src/pass-mechanics/PassExecutorState.cs:58` | 4 | 7 |
| transport-only | `PassExecutorState.LeadDistance` | `src/pass-mechanics/PassExecutorState.cs:61` | 5 | 3 |
| transport-only | `PassExecutorState.CachedPassing` | `src/pass-mechanics/PassExecutorState.cs:64` | 1 | 2 |
| transport-only | `PassExecutorState.CachedFatigue` | `src/pass-mechanics/PassExecutorState.cs:67` | 1 | 2 |
| transport-only | `PassExecutorState.CachedBodyAngleDeg` | `src/pass-mechanics/PassExecutorState.cs:70` | 1 | 2 |
| transport-only | `PassExecutorState.CachedIsWeakFoot` | `src/pass-mechanics/PassExecutorState.cs:73` | 1 | 2 |
| transport-only | `PassExecutorState.CachedWeakFootRating` | `src/pass-mechanics/PassExecutorState.cs:76` | 1 | 2 |
| transport-only | `PassExecutorState.WindupFramesRemaining` | `src/pass-mechanics/PassExecutorState.cs:79` | 1 | 2 |
| transport-only | `PassExecutorState.FollowThroughFramesRemaining` | `src/pass-mechanics/PassExecutorState.cs:82` | 1 | 2 |
| transport-only | `PassExecutorState.LastResult` | `src/pass-mechanics/PassExecutorState.cs:85` | 1 | 16 |
| transport-only | `PerceptionTickState.Latency` | `src/perception-system/PerceptionTickState.cs:26` | 1 | 6 |
| transport-only | `PerceptionTickState.ShoulderCheck` | `src/perception-system/PerceptionTickState.cs:29` | 1 | 11 |
| transport-only | `PerceptionTickState.BallPerceivedPositionPrev` | `src/perception-system/PerceptionTickState.cs:35` | 1 | 3 |
| transport-only | `PerceptionTickState.BallStalenessFramesPrev` | `src/perception-system/PerceptionTickState.cs:38` | 1 | 2 |
| transport-only | `RecognitionLatencyState.Confirmed` | `src/perception-system/RecognitionLatencyState.cs:25` | 1 | 1 |
| transport-only | `RecognitionLatencyState.ExpiryCounters` | `src/perception-system/RecognitionLatencyState.cs:28` | 1 | 1 |
| transport-only | `ShoulderCheckState.WindowExpiryFrame` | `src/perception-system/ShoulderCheckState.cs:26` | 1 | 1 |
| transport-only | `ShoulderCheckState.WindowActive` | `src/perception-system/ShoulderCheckState.cs:29` | 1 | 1 |
| transport-only | `ShoulderCheckState.AnimData` | `src/perception-system/ShoulderCheckState.cs:32` | 1 | 4 |
| transport-only | `ShoulderCheckState.BlindSideConfirmed` | `src/perception-system/ShoulderCheckState.cs:38` | 1 | 1 |
| transport-only | `MarkingDwellState.LastMarkerId` | `src/positioning-ai/MarkingDwellState.cs:35` | 3 | 1 |
| snapshot/state-carrier | `PositioningPerceptionSnapshot.ActiveOutfieldCount` | `src/positioning-ai/PositioningPerceptionSnapshot.cs:73` | 1 | 0 |
| snapshot/state-carrier | `PressingAgentSnapshot.HasBall` | `src/pressing-ai/PressingAgentSnapshot.cs:65` | 1 | 0 |
| snapshot/state-carrier | `PressingSnapshot.BallVelocity` | `src/pressing-ai/PressingSnapshot.cs:33` | 1 | 0 |
| snapshot/state-carrier | `PressingSnapshot.PossessionTeamId` | `src/pressing-ai/PressingSnapshot.cs:51` | 1 | 0 |
| transport-only | `PressingTickState.Roles` | `src/pressing-ai/PressingTickState.cs:28` | 1 | 5 |
| transport-only | `PressingTickState.Trigger` | `src/pressing-ai/PressingTickState.cs:31` | 1 | 9 |
| transport-only | `PressingTickState.DisengageDwell` | `src/pressing-ai/PressingTickState.cs:34` | 1 | 2 |
| transport-only | `PressingTickState.CooldownTicks` | `src/pressing-ai/PressingTickState.cs:37` | 1 | 2 |
| transport-only | `PressingTickState.PressFatigue` | `src/pressing-ai/PressingTickState.cs:40` | 1 | 2 |
| transport-only | `ShotExecutorState.State` | `src/shot-mechanics/ShotExecutorState.cs:35` | 1 | 2 |
| transport-only | `ShotExecutorState.Request` | `src/shot-mechanics/ShotExecutorState.cs:38` | 1 | 11 |
| transport-only | `ShotExecutorState.KickSpeed` | `src/shot-mechanics/ShotExecutorState.cs:41` | 1 | 2 |
| transport-only | `ShotExecutorState.LaunchAngleDeg` | `src/shot-mechanics/ShotExecutorState.cs:44` | 1 | 2 |
| transport-only | `ShotExecutorState.SpinVector` | `src/shot-mechanics/ShotExecutorState.cs:47` | 1 | 4 |
| transport-only | `ShotExecutorState.IntendedAimDirection` | `src/shot-mechanics/ShotExecutorState.cs:50` | 1 | 4 |
| transport-only | `ShotExecutorState.BodyMechanics` | `src/shot-mechanics/ShotExecutorState.cs:53` | 1 | 4 |
| transport-only | `ShotExecutorState.WeakFootErrorMultiplier` | `src/shot-mechanics/ShotExecutorState.cs:56` | 1 | 2 |
| transport-only | `ShotExecutorState.WindupFrames` | `src/shot-mechanics/ShotExecutorState.cs:59` | 2 | 2 |
| transport-only | `ShotExecutorState.CachedAgentPosition` | `src/shot-mechanics/ShotExecutorState.cs:62` | 1 | 4 |
| transport-only | `ShotExecutorState.CachedFinishing` | `src/shot-mechanics/ShotExecutorState.cs:65` | 1 | 2 |
| transport-only | `ShotExecutorState.CachedLongShots` | `src/shot-mechanics/ShotExecutorState.cs:68` | 1 | 2 |
| transport-only | `ShotExecutorState.CachedComposure` | `src/shot-mechanics/ShotExecutorState.cs:71` | 1 | 2 |
| transport-only | `ShotExecutorState.CachedFatigue` | `src/shot-mechanics/ShotExecutorState.cs:74` | 1 | 2 |
| transport-only | `ShotExecutorState.WindupFramesRemaining` | `src/shot-mechanics/ShotExecutorState.cs:77` | 1 | 2 |
| transport-only | `ShotExecutorState.FollowThroughFramesRemaining` | `src/shot-mechanics/ShotExecutorState.cs:80` | 1 | 2 |
| transport-only | `ShotExecutorState.LastResult` | `src/shot-mechanics/ShotExecutorState.cs:83` | 1 | 22 |

## `AgentState.LeanAngle`

- Declaration: `src/agent-movement/AgentState.cs:57`
- Category: `transport-only`
- Writes: `src/agent-movement/AgentMovementSystem.cs:334`, `src/agent-movement/AgentState.cs:102`, `src/match-engine/MatchEngine.cs:6663`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7238`

## `AgentState.CurrentTurnRate`

- Declaration: `src/agent-movement/AgentState.cs:60`
- Category: `transport-only`
- Writes: `src/agent-movement/AgentMovementSystem.cs:311`, `src/agent-movement/AgentState.cs:103`, `src/match-engine/MatchEngine.cs:6664`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7239`

## `OscillationGuardState.WriteIndex`

- Declaration: `src/agent-movement/OscillationGuardState.cs:36`
- Category: `transport-only`
- Writes: `src/agent-movement/OscillationGuardState.cs:49`
- Transport-only reads: `src/agent-movement/OscillationGuard.cs:112`, `src/match-engine/MatchEngine.cs:7264`

## `OscillationGuardState.IsLocked`

- Declaration: `src/agent-movement/OscillationGuardState.cs:39`
- Category: `transport-only`
- Writes: `src/agent-movement/OscillationGuardState.cs:50`
- Transport-only reads: `src/agent-movement/OscillationGuard.cs:113`, `src/match-engine/MatchEngine.cs:7265`

## `OscillationGuardState.LockUntilTime`

- Declaration: `src/agent-movement/OscillationGuardState.cs:42`
- Category: `transport-only`
- Writes: `src/agent-movement/OscillationGuardState.cs:51`
- Transport-only reads: `src/agent-movement/OscillationGuard.cs:114`, `src/match-engine/MatchEngine.cs:7266`

## `AttackingTickState.Hysteresis`

- Declaration: `src/attacking-ai/AttackingTickState.cs:27`
- Category: `transport-only`
- Writes: `src/attacking-ai/AttackingTickState.cs:41`
- Transport-only reads: `src/attacking-ai/AttackingAITick.cs:267`, `src/match-engine/MatchEngine.cs:7010`, `src/match-engine/MatchEngine.cs:7897`

## `AttackingTickState.Transition`

- Declaration: `src/attacking-ai/AttackingTickState.cs:30`
- Category: `transport-only`
- Writes: `src/attacking-ai/AttackingTickState.cs:42`
- Transport-only reads: `src/attacking-ai/AttackingAITick.cs:270`, `src/match-engine/MatchEngine.cs:7889`, `src/match-engine/MatchEngine.cs:7890`

## `AttackingTickState.LastInPossDirective`

- Declaration: `src/attacking-ai/AttackingTickState.cs:33`
- Category: `transport-only`
- Writes: `src/attacking-ai/AttackingTickState.cs:43`
- Transport-only reads: `src/attacking-ai/AttackingAITick.cs:271`, `src/match-engine/MatchEngine.cs:7892`, `src/match-engine/MatchEngine.cs:7893`, `src/match-engine/MatchEngine.cs:7894`, `src/match-engine/MatchEngine.cs:7895`

## `CollisionContactState.Word0`

- Declaration: `src/collision-system/CollisionContactState.cs:21`
- Category: `transport-only`
- Writes: `src/collision-system/CollisionContactState.cs:35`
- Transport-only reads: `src/collision-system/CollisionSystem.cs:115`, `src/match-engine/MatchEngine.cs:6325`

## `CollisionContactState.Word1`

- Declaration: `src/collision-system/CollisionContactState.cs:24`
- Category: `transport-only`
- Writes: `src/collision-system/CollisionContactState.cs:36`
- Transport-only reads: `src/collision-system/CollisionSystem.cs:115`, `src/match-engine/MatchEngine.cs:6326`

## `CollisionContactState.Word2`

- Declaration: `src/collision-system/CollisionContactState.cs:27`
- Category: `transport-only`
- Writes: `src/collision-system/CollisionContactState.cs:37`
- Transport-only reads: `src/collision-system/CollisionSystem.cs:115`, `src/match-engine/MatchEngine.cs:6327`

## `CollisionContactState.Word3`

- Declaration: `src/collision-system/CollisionContactState.cs:30`
- Category: `transport-only`
- Writes: `src/collision-system/CollisionContactState.cs:38`
- Transport-only reads: `src/collision-system/CollisionSystem.cs:115`, `src/match-engine/MatchEngine.cs:6328`

## `DecisionTreeState.State`

- Declaration: `src/decision-tree/DecisionTreeState.cs:43`
- Category: `transport-only`
- Writes: `src/decision-tree/DecisionTreeState.cs:57`
- Transport-only reads: `src/decision-tree/DecisionTree.cs:122`, `src/match-engine/MatchEngine.cs:7416`

## `DefensiveAgentSnapshot.HasBall`

- Declaration: `src/defensive-ai/DefensiveAgentSnapshot.cs:53`
- Category: `snapshot/state-carrier`
- Writes: `src/match-engine/MatchEngine.cs:4095`
- Transport-only reads: none

## `DefensiveSnapshot.PossessionOwnerEntityId`

- Declaration: `src/defensive-ai/DefensiveSnapshot.cs:42`
- Category: `snapshot/state-carrier`
- Writes: `src/match-engine/MatchEngine.cs:4034`
- Transport-only reads: none

## `DefensiveTickState.Hysteresis`

- Declaration: `src/defensive-ai/DefensiveTickState.cs:28`
- Category: `transport-only`
- Writes: `src/defensive-ai/DefensiveTickState.cs:42`
- Transport-only reads: `src/defensive-ai/DefensiveAITick.cs:347`, `src/match-engine/MatchEngine.cs:6976`, `src/match-engine/MatchEngine.cs:7863`

## `DefensiveTickState.PrevAssignments`

- Declaration: `src/defensive-ai/DefensiveTickState.cs:31`
- Category: `transport-only`
- Writes: `src/defensive-ai/DefensiveTickState.cs:43`
- Transport-only reads: `src/defensive-ai/DefensiveAITick.cs:348`, `src/match-engine/MatchEngine.cs:7864`

## `RngStreamState.DrawIndex`

- Declaration: `src/deterministic-sim/RngStreamState.cs:40`
- Category: `snapshot/state-carrier`
- Writes: `src/deterministic-sim/DeterministicRngService.cs:96`, `src/deterministic-sim/RngStreamState.cs:59`
- Transport-only reads: none

## `RngStreamState.SiteId`

- Declaration: `src/deterministic-sim/RngStreamState.cs:43`
- Category: `snapshot/state-carrier`
- Writes: `src/deterministic-sim/DeterministicRngService.cs:65`
- Transport-only reads: none

## `RngStreamState.StreamVersion`

- Declaration: `src/deterministic-sim/RngStreamState.cs:46`
- Category: `snapshot/state-carrier`
- Writes: `src/deterministic-sim/DeterministicRngService.cs:68`
- Transport-only reads: none

## `RngStreamState.EntityId`

- Declaration: `src/deterministic-sim/RngStreamState.cs:52`
- Category: `snapshot/state-carrier`
- Writes: `src/deterministic-sim/DeterministicRngService.cs:67`
- Transport-only reads: none

## `GkContactState.PredictedContactFrame`

- Declaration: `src/goalkeeper-mechanics/GkContactState.cs:23`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GkContactState.cs:57`, `src/match-engine/MatchEngine.cs:7647`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7525`

## `GkContactState.ActualContactFrame`

- Declaration: `src/goalkeeper-mechanics/GkContactState.cs:26`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GkContactState.cs:58`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:795`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:981`, `src/match-engine/MatchEngine.cs:7648`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7526`

## `GkContactState.HandlingQualityScalar`

- Declaration: `src/goalkeeper-mechanics/GkContactState.cs:35`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GkContactState.cs:60`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:794`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:808`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:839`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:980`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:993`, `src/match-engine/MatchEngine.cs:7650`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7528`

## `GoalkeeperTickState.Attrs`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:33`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:122`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:476`, `src/match-engine/MatchEngine.cs:7510`

## `GoalkeeperTickState.ContactStates`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:36`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:123`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:477`, `src/match-engine/MatchEngine.cs:7524`

## `GoalkeeperTickState.SaveIntents`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:39`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:124`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:478`, `src/match-engine/MatchEngine.cs:7534`

## `GoalkeeperTickState.SaveIntentActive`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:42`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:125`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:479`, `src/match-engine/MatchEngine.cs:7547`

## `GoalkeeperTickState.RushIntents`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:45`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:126`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:480`, `src/match-engine/MatchEngine.cs:7549`

## `GoalkeeperTickState.RushIntentActive`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:48`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:127`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:481`, `src/match-engine/MatchEngine.cs:7555`

## `GoalkeeperTickState.DistributeIntents`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:51`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:128`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:482`, `src/match-engine/MatchEngine.cs:7557`

## `GoalkeeperTickState.DistributeIntentActive`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:54`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:129`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:483`, `src/match-engine/MatchEngine.cs:7572`

## `GoalkeeperTickState.PositioningContracts`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:57`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:130`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:484`, `src/match-engine/MatchEngine.cs:7574`

## `GoalkeeperTickState.DiveLaunchFrames`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:60`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:131`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:485`, `src/match-engine/MatchEngine.cs:7578`

## `GoalkeeperTickState.DiveDurationFrames`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:63`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:132`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:486`, `src/match-engine/MatchEngine.cs:7579`

## `GoalkeeperTickState.DivePeakHandZ`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:66`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:133`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:487`, `src/match-engine/MatchEngine.cs:7580`

## `GoalkeeperTickState.DiveDirectionLateral`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:69`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:134`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:488`, `src/match-engine/MatchEngine.cs:7581`

## `GoalkeeperTickState.RushLaunchMps`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:72`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:1127`, `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:914`, `src/goalkeeper-mechanics/GoalkeeperTickState.cs:135`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:489`, `src/match-engine/MatchEngine.cs:7582`

## `GoalkeeperTickState.RushInitialAttackerId`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:75`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:136`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:490`, `src/match-engine/MatchEngine.cs:7583`

## `GoalkeeperTickState.ShotDetectedTickMs`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:78`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:137`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:491`, `src/match-engine/MatchEngine.cs:7584`

## `GoalkeeperTickState.RequiredReactionMs`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:81`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:138`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:492`, `src/match-engine/MatchEngine.cs:7585`

## `GoalkeeperTickState.ShotEventPending`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:84`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:139`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:493`, `src/match-engine/MatchEngine.cs:7586`

## `GoalkeeperTickState.ClaimTick`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:87`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:140`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:494`, `src/match-engine/MatchEngine.cs:7587`

## `GoalkeeperTickState.ReleaseTickEarliest`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:90`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:141`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:495`, `src/match-engine/MatchEngine.cs:7588`

## `GoalkeeperTickState.RecoveryCooldownEndTick`

- Declaration: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:93`
- Category: `transport-only`
- Writes: `src/goalkeeper-mechanics/GoalkeeperTickState.cs:142`
- Transport-only reads: `src/goalkeeper-mechanics/GoalkeeperMechanics.cs:496`, `src/match-engine/MatchEngine.cs:7589`

## `HeaderContactState.ContactPointError`

- Declaration: `src/heading-mechanics/HeaderContactState.cs:43`
- Category: `transport-only`
- Writes: `src/heading-mechanics/HeaderContactState.cs:74`, `src/heading-mechanics/HeadingMechanics.cs:320`, `src/match-engine/MatchEngine.cs:7800`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7749`, `src/match-engine/MatchEngine.cs:7750`

## `HeaderContactState.DisturbanceFactor`

- Declaration: `src/heading-mechanics/HeaderContactState.cs:49`
- Category: `transport-only`
- Writes: `src/heading-mechanics/HeaderContactState.cs:76`, `src/match-engine/MatchEngine.cs:7802`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7752`

## `HeadingTickState.ContactStates`

- Declaration: `src/heading-mechanics/HeadingTickState.cs:33`
- Category: `transport-only`
- Writes: `src/heading-mechanics/HeadingTickState.cs:54`
- Transport-only reads: `src/heading-mechanics/HeadingMechanics.cs:155`, `src/match-engine/MatchEngine.cs:7743`

## `HeadingTickState.IntentActive`

- Declaration: `src/heading-mechanics/HeadingTickState.cs:36`
- Category: `transport-only`
- Writes: `src/heading-mechanics/HeadingTickState.cs:55`
- Transport-only reads: `src/heading-mechanics/HeadingMechanics.cs:156`, `src/match-engine/MatchEngine.cs:7757`

## `HeadingTickState.BallSnapshotFrames`

- Declaration: `src/heading-mechanics/HeadingTickState.cs:39`
- Category: `transport-only`
- Writes: `src/heading-mechanics/HeadingTickState.cs:56`
- Transport-only reads: `src/heading-mechanics/HeadingMechanics.cs:157`, `src/match-engine/MatchEngine.cs:7758`

## `HeadingTickState.AgentAttrs`

- Declaration: `src/heading-mechanics/HeadingTickState.cs:42`
- Category: `transport-only`
- Writes: `src/heading-mechanics/HeadingTickState.cs:57`
- Transport-only reads: `src/heading-mechanics/HeadingMechanics.cs:158`, `src/match-engine/MatchEngine.cs:7760`

## `PassExecutorState.State`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:37`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:107`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7290`, `src/pass-mechanics/PassExecutor.cs:169`

## `PassExecutorState.Request`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:40`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:108`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7292`, `src/match-engine/MatchEngine.cs:7293`, `src/match-engine/MatchEngine.cs:7294`, `src/match-engine/MatchEngine.cs:7295`, `src/match-engine/MatchEngine.cs:7296`, `src/match-engine/MatchEngine.cs:7297`, `src/match-engine/MatchEngine.cs:7298`, `src/match-engine/MatchEngine.cs:7299`, `src/match-engine/MatchEngine.cs:7300`, `src/match-engine/MatchEngine.cs:7301`, `src/match-engine/MatchEngine.cs:7302`, `src/match-engine/MatchEngine.cs:7303`, `src/pass-mechanics/PassExecutor.cs:170`, `src/pass-mechanics/PassExecutor.cs:179`

## `PassExecutorState.EffectiveSubType`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:43`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:109`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7305`, `src/pass-mechanics/PassExecutor.cs:171`, `src/pass-mechanics/PassExecutor.cs:179`

## `PassExecutorState.KickSpeed`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:46`
- Category: `transport-only`
- Writes: `src/match-engine/MatchEngine.cs:6808`, `src/pass-mechanics/PassExecutorState.cs:110`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7306`, `src/pass-mechanics/PassExecutor.cs:181`

## `PassExecutorState.LaunchAngleDeg`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:49`
- Category: `transport-only`
- Writes: `src/match-engine/MatchEngine.cs:6809`, `src/pass-mechanics/PassExecutorState.cs:111`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7307`, `src/pass-mechanics/PassExecutor.cs:182`

## `PassExecutorState.SpinVector`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:52`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:112`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7308`, `src/match-engine/MatchEngine.cs:7309`, `src/match-engine/MatchEngine.cs:7310`, `src/pass-mechanics/PassExecutor.cs:183`

## `PassExecutorState.BaseKickDirection`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:55`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:113`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7311`, `src/match-engine/MatchEngine.cs:7312`, `src/match-engine/MatchEngine.cs:7313`, `src/pass-mechanics/PassExecutor.cs:184`

## `PassExecutorState.AimPoint`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:58`
- Category: `transport-only`
- Writes: `src/match-engine/MatchEngine.cs:6744`, `src/pass-mechanics/PassExecutor.cs:359`, `src/pass-mechanics/PassExecutor.cs:495`, `src/pass-mechanics/PassExecutorState.cs:114`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7314`, `src/match-engine/MatchEngine.cs:7315`, `src/match-engine/MatchEngine.cs:7316`, `src/match-engine/MatchEngine.cs:7333`, `src/match-engine/MatchEngine.cs:7334`, `src/match-engine/MatchEngine.cs:7335`, `src/pass-mechanics/PassExecutor.cs:185`

## `PassExecutorState.LeadDistance`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:61`
- Category: `transport-only`
- Writes: `src/match-engine/MatchEngine.cs:6746`, `src/pass-mechanics/PassExecutor.cs:360`, `src/pass-mechanics/PassExecutor.cs:497`, `src/pass-mechanics/PassExecutor.cs:524`, `src/pass-mechanics/PassExecutorState.cs:115`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7317`, `src/match-engine/MatchEngine.cs:7337`, `src/pass-mechanics/PassExecutor.cs:186`

## `PassExecutorState.CachedPassing`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:64`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:116`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7318`, `src/pass-mechanics/PassExecutor.cs:187`

## `PassExecutorState.CachedFatigue`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:67`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:117`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7319`, `src/pass-mechanics/PassExecutor.cs:188`

## `PassExecutorState.CachedBodyAngleDeg`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:70`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:118`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7320`, `src/pass-mechanics/PassExecutor.cs:189`

## `PassExecutorState.CachedIsWeakFoot`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:73`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:119`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7321`, `src/pass-mechanics/PassExecutor.cs:190`

## `PassExecutorState.CachedWeakFootRating`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:76`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:120`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7322`, `src/pass-mechanics/PassExecutor.cs:191`

## `PassExecutorState.WindupFramesRemaining`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:79`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:121`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7323`, `src/pass-mechanics/PassExecutor.cs:192`

## `PassExecutorState.FollowThroughFramesRemaining`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:82`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:122`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7324`, `src/pass-mechanics/PassExecutor.cs:193`

## `PassExecutorState.LastResult`

- Declaration: `src/pass-mechanics/PassExecutorState.cs:85`
- Category: `transport-only`
- Writes: `src/pass-mechanics/PassExecutorState.cs:123`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7326`, `src/match-engine/MatchEngine.cs:7327`, `src/match-engine/MatchEngine.cs:7328`, `src/match-engine/MatchEngine.cs:7329`, `src/match-engine/MatchEngine.cs:7330`, `src/match-engine/MatchEngine.cs:7331`, `src/match-engine/MatchEngine.cs:7332`, `src/match-engine/MatchEngine.cs:7333`, `src/match-engine/MatchEngine.cs:7334`, `src/match-engine/MatchEngine.cs:7335`, `src/match-engine/MatchEngine.cs:7336`, `src/match-engine/MatchEngine.cs:7337`, `src/match-engine/MatchEngine.cs:7338`, `src/match-engine/MatchEngine.cs:7339`, `src/match-engine/MatchEngine.cs:7340`, `src/pass-mechanics/PassExecutor.cs:194`

## `PerceptionTickState.Latency`

- Declaration: `src/perception-system/PerceptionTickState.cs:26`
- Category: `transport-only`
- Writes: `src/perception-system/PerceptionTickState.cs:51`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7040`, `src/match-engine/MatchEngine.cs:7913`, `src/perception-system/PerceptionSystem.cs:155`, `src/perception-system/PerceptionSystem.cs:158`, `src/perception-system/PerceptionSystem.cs:159`, `src/perception-system/PerceptionSystem.cs:160`

## `PerceptionTickState.ShoulderCheck`

- Declaration: `src/perception-system/PerceptionTickState.cs:29`
- Category: `transport-only`
- Writes: `src/perception-system/PerceptionTickState.cs:52`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7051`, `src/match-engine/MatchEngine.cs:7067`, `src/match-engine/MatchEngine.cs:7922`, `src/perception-system/PerceptionSystem.cs:163`, `src/perception-system/PerceptionSystem.cs:166`, `src/perception-system/PerceptionSystem.cs:167`, `src/perception-system/PerceptionSystem.cs:168`, `src/perception-system/PerceptionSystem.cs:169`, `src/perception-system/PerceptionSystem.cs:172`, `src/perception-system/PerceptionSystem.cs:175`, `src/perception-system/PerceptionSystem.cs:176`

## `PerceptionTickState.BallPerceivedPositionPrev`

- Declaration: `src/perception-system/PerceptionTickState.cs:35`
- Category: `transport-only`
- Writes: `src/perception-system/PerceptionTickState.cs:54`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7946`, `src/match-engine/MatchEngine.cs:7947`, `src/perception-system/PerceptionSystem.cs:183`

## `PerceptionTickState.BallStalenessFramesPrev`

- Declaration: `src/perception-system/PerceptionTickState.cs:38`
- Category: `transport-only`
- Writes: `src/perception-system/PerceptionTickState.cs:55`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7948`, `src/perception-system/PerceptionSystem.cs:184`

## `RecognitionLatencyState.Confirmed`

- Declaration: `src/perception-system/RecognitionLatencyState.cs:25`
- Category: `transport-only`
- Writes: `src/perception-system/RecognitionLatencyState.cs:37`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7918`

## `RecognitionLatencyState.ExpiryCounters`

- Declaration: `src/perception-system/RecognitionLatencyState.cs:28`
- Category: `transport-only`
- Writes: `src/perception-system/RecognitionLatencyState.cs:38`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7919`

## `ShoulderCheckState.WindowExpiryFrame`

- Declaration: `src/perception-system/ShoulderCheckState.cs:26`
- Category: `transport-only`
- Writes: `src/perception-system/ShoulderCheckState.cs:56`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7927`

## `ShoulderCheckState.WindowActive`

- Declaration: `src/perception-system/ShoulderCheckState.cs:29`
- Category: `transport-only`
- Writes: `src/perception-system/ShoulderCheckState.cs:57`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7928`

## `ShoulderCheckState.AnimData`

- Declaration: `src/perception-system/ShoulderCheckState.cs:32`
- Category: `transport-only`
- Writes: `src/perception-system/ShoulderCheckState.cs:58`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7929`, `src/match-engine/MatchEngine.cs:7930`, `src/match-engine/MatchEngine.cs:7931`, `src/match-engine/MatchEngine.cs:7932`

## `ShoulderCheckState.BlindSideConfirmed`

- Declaration: `src/perception-system/ShoulderCheckState.cs:38`
- Category: `transport-only`
- Writes: `src/perception-system/ShoulderCheckState.cs:60`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7939`

## `MarkingDwellState.LastMarkerId`

- Declaration: `src/positioning-ai/MarkingDwellState.cs:35`
- Category: `transport-only`
- Writes: `src/match-engine/MatchEngine.cs:6482`, `src/positioning-ai/MarkingPressureEvaluator.cs:108`, `src/positioning-ai/MarkingPressureEvaluator.cs:114`
- Transport-only reads: `src/match-engine/MatchEngine.cs:6165`

## `PositioningPerceptionSnapshot.ActiveOutfieldCount`

- Declaration: `src/positioning-ai/PositioningPerceptionSnapshot.cs:73`
- Category: `snapshot/state-carrier`
- Writes: `src/match-engine/MatchEngine.cs:3923`
- Transport-only reads: none

## `PressingAgentSnapshot.HasBall`

- Declaration: `src/pressing-ai/PressingAgentSnapshot.cs:65`
- Category: `snapshot/state-carrier`
- Writes: `src/match-engine/MatchEngine.cs:3997`
- Transport-only reads: none

## `PressingSnapshot.BallVelocity`

- Declaration: `src/pressing-ai/PressingSnapshot.cs:33`
- Category: `snapshot/state-carrier`
- Writes: `src/match-engine/MatchEngine.cs:3959`
- Transport-only reads: none

## `PressingSnapshot.PossessionTeamId`

- Declaration: `src/pressing-ai/PressingSnapshot.cs:51`
- Category: `snapshot/state-carrier`
- Writes: `src/match-engine/MatchEngine.cs:3970`
- Transport-only reads: none

## `PressingTickState.Roles`

- Declaration: `src/pressing-ai/PressingTickState.cs:28`
- Category: `transport-only`
- Writes: `src/pressing-ai/PressingTickState.cs:50`
- Transport-only reads: `src/match-engine/MatchEngine.cs:6943`, `src/match-engine/MatchEngine.cs:7841`, `src/pressing-ai/PressingAITick.cs:305`, `src/pressing-ai/PressingAITick.cs:306`, `src/pressing-ai/PressingAITick.cs:307`

## `PressingTickState.Trigger`

- Declaration: `src/pressing-ai/PressingTickState.cs:31`
- Category: `transport-only`
- Writes: `src/pressing-ai/PressingTickState.cs:51`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7829`, `src/match-engine/MatchEngine.cs:7830`, `src/match-engine/MatchEngine.cs:7831`, `src/match-engine/MatchEngine.cs:7832`, `src/match-engine/MatchEngine.cs:7833`, `src/match-engine/MatchEngine.cs:7834`, `src/match-engine/MatchEngine.cs:7835`, `src/match-engine/MatchEngine.cs:7836`, `src/pressing-ai/PressingAITick.cs:311`

## `PressingTickState.DisengageDwell`

- Declaration: `src/pressing-ai/PressingTickState.cs:34`
- Category: `transport-only`
- Writes: `src/pressing-ai/PressingTickState.cs:52`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7838`, `src/pressing-ai/PressingAITick.cs:312`

## `PressingTickState.CooldownTicks`

- Declaration: `src/pressing-ai/PressingTickState.cs:37`
- Category: `transport-only`
- Writes: `src/pressing-ai/PressingTickState.cs:53`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7839`, `src/pressing-ai/PressingAITick.cs:313`

## `PressingTickState.PressFatigue`

- Declaration: `src/pressing-ai/PressingTickState.cs:40`
- Category: `transport-only`
- Writes: `src/pressing-ai/PressingTickState.cs:54`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7842`, `src/pressing-ai/PressingAITick.cs:308`

## `ShotExecutorState.State`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:35`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:105`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7348`, `src/shot-mechanics/ShotExecutor.cs:153`

## `ShotExecutorState.Request`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:38`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:106`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7350`, `src/match-engine/MatchEngine.cs:7351`, `src/match-engine/MatchEngine.cs:7352`, `src/match-engine/MatchEngine.cs:7353`, `src/match-engine/MatchEngine.cs:7354`, `src/match-engine/MatchEngine.cs:7355`, `src/match-engine/MatchEngine.cs:7356`, `src/match-engine/MatchEngine.cs:7357`, `src/match-engine/MatchEngine.cs:7358`, `src/match-engine/MatchEngine.cs:7359`, `src/shot-mechanics/ShotExecutor.cs:154`

## `ShotExecutorState.KickSpeed`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:41`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:107`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7361`, `src/shot-mechanics/ShotExecutor.cs:155`

## `ShotExecutorState.LaunchAngleDeg`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:44`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:108`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7362`, `src/shot-mechanics/ShotExecutor.cs:156`

## `ShotExecutorState.SpinVector`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:47`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:109`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7363`, `src/match-engine/MatchEngine.cs:7364`, `src/match-engine/MatchEngine.cs:7365`, `src/shot-mechanics/ShotExecutor.cs:157`

## `ShotExecutorState.IntendedAimDirection`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:50`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:110`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7366`, `src/match-engine/MatchEngine.cs:7367`, `src/match-engine/MatchEngine.cs:7368`, `src/shot-mechanics/ShotExecutor.cs:158`

## `ShotExecutorState.BodyMechanics`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:53`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:111`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7370`, `src/match-engine/MatchEngine.cs:7371`, `src/match-engine/MatchEngine.cs:7372`, `src/shot-mechanics/ShotExecutor.cs:159`

## `ShotExecutorState.WeakFootErrorMultiplier`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:56`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:112`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7374`, `src/shot-mechanics/ShotExecutor.cs:160`

## `ShotExecutorState.WindupFrames`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:59`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotEventEmitter.cs:80`, `src/shot-mechanics/ShotExecutorState.cs:113`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7375`, `src/shot-mechanics/ShotExecutor.cs:161`

## `ShotExecutorState.CachedAgentPosition`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:62`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:114`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7376`, `src/match-engine/MatchEngine.cs:7377`, `src/match-engine/MatchEngine.cs:7378`, `src/shot-mechanics/ShotExecutor.cs:162`

## `ShotExecutorState.CachedFinishing`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:65`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:115`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7379`, `src/shot-mechanics/ShotExecutor.cs:163`

## `ShotExecutorState.CachedLongShots`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:68`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:116`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7380`, `src/shot-mechanics/ShotExecutor.cs:164`

## `ShotExecutorState.CachedComposure`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:71`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:117`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7381`, `src/shot-mechanics/ShotExecutor.cs:165`

## `ShotExecutorState.CachedFatigue`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:74`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:118`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7382`, `src/shot-mechanics/ShotExecutor.cs:166`

## `ShotExecutorState.WindupFramesRemaining`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:77`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:119`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7383`, `src/shot-mechanics/ShotExecutor.cs:167`

## `ShotExecutorState.FollowThroughFramesRemaining`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:80`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:120`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7384`, `src/shot-mechanics/ShotExecutor.cs:168`

## `ShotExecutorState.LastResult`

- Declaration: `src/shot-mechanics/ShotExecutorState.cs:83`
- Category: `transport-only`
- Writes: `src/shot-mechanics/ShotExecutorState.cs:121`
- Transport-only reads: `src/match-engine/MatchEngine.cs:7386`, `src/match-engine/MatchEngine.cs:7387`, `src/match-engine/MatchEngine.cs:7388`, `src/match-engine/MatchEngine.cs:7389`, `src/match-engine/MatchEngine.cs:7390`, `src/match-engine/MatchEngine.cs:7391`, `src/match-engine/MatchEngine.cs:7392`, `src/match-engine/MatchEngine.cs:7393`, `src/match-engine/MatchEngine.cs:7394`, `src/match-engine/MatchEngine.cs:7395`, `src/match-engine/MatchEngine.cs:7396`, `src/match-engine/MatchEngine.cs:7397`, `src/match-engine/MatchEngine.cs:7398`, `src/match-engine/MatchEngine.cs:7399`, `src/match-engine/MatchEngine.cs:7400`, `src/match-engine/MatchEngine.cs:7401`, `src/match-engine/MatchEngine.cs:7402`, `src/match-engine/MatchEngine.cs:7403`, `src/match-engine/MatchEngine.cs:7404`, `src/match-engine/MatchEngine.cs:7405`, `src/match-engine/MatchEngine.cs:7406`, `src/shot-mechanics/ShotExecutor.cs:169`

